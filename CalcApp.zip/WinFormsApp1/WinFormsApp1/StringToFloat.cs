﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CalcApp
{
    public class StringToFloat
    {
        public static bool isConvertible(string str)
        {
            float float1;
            bool check1 = float.TryParse(str, out float1);
            return check1;
        }

        public static float Float(string str)
        {
            float float1;
            bool check1 = float.TryParse(str, out float1);
            return float1;
        }
    }
}
