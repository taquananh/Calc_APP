﻿using Python.Runtime;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Python.Runtime.TypeSpec;
using WinFormsApp1;

namespace CalcApp
{
    public partial class AddCircle : Form
    {
        public RunPythonScript RPS = new RunPythonScript();
        public dynamic OCP, Plotting, Space;
        public dynamic Plot = (new Pyplot()).pyplot();
        public AddCircle()
        {
            InitializeComponent();
            OCP = RPS.OpenClosePlot();
            Plotting = RPS.Plotting();
        }

        private void Confirm_Click(object sender, EventArgs e)
        {
            float float1, float2, float3;
            bool check1, check2, check3;
            check1 = float.TryParse(xValue.Text, out float1);
            check2 = float.TryParse(yValue.Text, out float2);
            check3 = float.TryParse(RadiusText.Text, out float3);

            if (check1 && check2 && check3)
                using (Py.GIL())
                {
                    PyFloat x = new PyFloat(float1);
                    PyFloat y = new PyFloat(float2);
                    PyFloat R = new PyFloat(float3);
                    PyString name = new PyString(CircleNameText.Text);
                    PyString pntname = new PyString(CenterNameText.Text);

                    dynamic center = Plotting.Shapes.Point(x, y, pntname);
                    dynamic circ = Plotting.Shapes.Circle(center, R, name);
                    Form1.Surface.InvokeMethod("AddItem", new PyObject[] { center });
                    Form1.Surface.InvokeMethod("AddItem", new PyObject[] { circ });
                    Form1.Surface.InvokeMethod("Plot", new PyObject[] { center });
                    Form1.Surface.InvokeMethod("Plot", new PyObject[] { circ });
                    OCP.ShowPlot();

                    string centername = center.name;
                    string pointname = circ.name;
                    Form1.NewItems(centername);
                    Form1.NewItems(pointname);
                    //PyObject A = Surface.Point().InvokeMethod("Point", new PyObject[] { x, y });
                }
        }
    }
}
