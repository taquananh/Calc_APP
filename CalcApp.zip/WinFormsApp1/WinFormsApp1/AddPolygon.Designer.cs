﻿namespace CalcApp
{
    partial class AddPolygon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox3 = new GroupBox();
            Confirmation = new Button();
            PolygonCode = new RichTextBox();
            label8 = new Label();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(Confirmation);
            groupBox3.Controls.Add(PolygonCode);
            groupBox3.Controls.Add(label8);
            groupBox3.Location = new Point(12, 12);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(385, 339);
            groupBox3.TabIndex = 9;
            groupBox3.TabStop = false;
            groupBox3.Text = "Nhập đa giác";
            // 
            // Confirmation
            // 
            Confirmation.Location = new Point(277, 298);
            Confirmation.Name = "Confirmation";
            Confirmation.Size = new Size(94, 29);
            Confirmation.TabIndex = 9;
            Confirmation.Text = "OK";
            Confirmation.UseVisualStyleBackColor = true;
            Confirmation.Click += Confirmation_Click;
            // 
            // PolygonCode
            // 
            PolygonCode.Location = new Point(11, 110);
            PolygonCode.Name = "PolygonCode";
            PolygonCode.Size = new Size(365, 182);
            PolygonCode.TabIndex = 2;
            PolygonCode.Text = "";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 23);
            label8.Name = "label8";
            label8.Size = new Size(365, 80);
            label8.TabIndex = 1;
            label8.Text = "Nhập tên đa giác, tên các điểm theo mẫu:\r\n[Tên] Điểm1 Điểm2 ...\r\nVí dụ, nhập tam giác ABC có các điểm A, B, C như sau:\r\n[ABC] A B C";
            // 
            // AddPolygon
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(407, 361);
            Controls.Add(groupBox3);
            Name = "AddPolygon";
            Text = "AddPolygon";
            Load += AddPolygon_Load;
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox3;
        private Button Confirmation;
        private RichTextBox PolygonCode;
        private Label label8;
    }
}