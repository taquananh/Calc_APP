﻿using Python.Runtime;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1;

namespace CalcApp
{
    public partial class AddPolygon : Form
    {
        public AddPolygon()
        {
            InitializeComponent();
        }

        public RunPythonScript RPS = new RunPythonScript();
        public dynamic OCP, Plotting, Space;
        public dynamic Plot = (new Pyplot()).pyplot();
        private void AddPolygon_Load(object sender, EventArgs e)
        {
            OCP = RPS.OpenClosePlot();
            Plotting = RPS.Plotting();
        }

        private void Confirmation_Click(object sender, EventArgs e)
        {
            using (Py.GIL())
            {
                dynamic Polygon = Form1.Plotting.CodeTranslation.PolygonCodeTranslation(PolygonCode.Text);
                PyObject PyPo = Polygon;
                Form1.Surface.InvokeMethod("AddItem", new PyObject[] { PyPo });
                Form1.Surface.InvokeMethod("Plot", new PyObject[] { PyPo });
                OCP.ShowPlot();

                string objname = Polygon.name;
                Form1.NewItems(objname);
            }
        }

        
    }
}
