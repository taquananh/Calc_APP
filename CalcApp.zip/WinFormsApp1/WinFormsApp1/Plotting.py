﻿from matplotlib import pyplot as pyplot
from matplotlib import axes as axis

import math
import numpy
    
class Space:
    def __init__(self):
        pyplot.xlim(-10, 10)
        pyplot.ylim(-10, 10)
        self.Xmin = -10
        self.Xmax = 10
        self.Ymin = -10
        self.Ymax = 10
        
    items = []
    def AddItem(self, item):
        self.items += [item]
    
    def FindItem(self, itemname):
        for item in self.items:
            if (item.name == itemname):
                return item
    
    def RemoveItem(self, itemname):
        item = self.FindItem(itemname)
        self.items.remove(item)
    
    def Plot(self, item):
        infinite_Xmin = -1e7
        infinite_Xmax = 1e7
        infinite_Xmin_Poly = -1e3
        infinite_Xmax_Poly = 1e3

        if (item.type == "Point"):
            pyplot.plot(item.X, item.Y, marker = ".")
        elif (item.type == "Segment"):
            pyplot.plot([item.End1.X, item.End2.X], [item.End1.Y, item.End2.Y])
        elif (item.type == "Line"):
            a, b = item.A, item.B
            VerticalValues = [x for x in numpy.arange(infinite_Xmin, infinite_Xmax, 1e6)]
            HorizontalValues = [a*x + b for x in numpy.arange(infinite_Xmin, infinite_Xmax, 1e6)]
            pyplot.plot(VerticalValues, HorizontalValues)
            
        elif (item.type == "Circle"):
            R = item.R
            O = item.Center
            Circ = pyplot.Circle((O.X, O.Y), R, fill = False)
            pyplot.gca().add_patch(Circ)
            
        elif (item.type == "Triangle"):
            A, B, C = [item.A.X, item.A.Y], [item.B.X, item.B.Y], [item.C.X, item.C.Y]
            VerticalValues, HorizontalValues = zip(*[A, B, C, A])
            pyplot.plot(VerticalValues, HorizontalValues)
                
            
        elif (item.type == "Quadrilateral"):
            A, B, C, D = [item.A.X, item.A.Y], [item.B.X, item.B.Y], [item.C.X, item.C.Y], [item.D.X, item.D.Y]
            VerticalValues, HorizontalValues = zip(*[A, B, C, D, A])
            pyplot.plot(VerticalValues, HorizontalValues)
            
        elif (item.type == "Polygon"):
            Points = []
            for point in item.ListOfPoints:
                Points += [[point.X, point.Y]]
            Points += [Points[0]]

            VerticalValues, HorizontalValues = zip(*Points)
            pyplot.plot(VerticalValues, HorizontalValues)
            
        elif (item.type == "Rectangle"):
            pass
           
        elif (item.type == "Square"):
            pass
           
        elif (item.type == "Parabol"):
            a, b, c = item.A, item.B, item.C

            def f(x):
                s = (a*x*x + b*x + c)
                return s
            
            X1, X2 = 0, 0
            while ((f(X1) >= infinite_Xmin) and (X1 >= infinite_Xmin)):
                X1 -= 1
                if (X1 == -1e4):
                    break
            while ((f(X2) <= infinite_Xmax) and (X2 <= infinite_Xmax)):
                X2 += 1
                if (X2 == 1e4):
                    break
            
            VerticalValues = [x for x in numpy.arange(X1, X2, 1e-2)]
            HorizontalValues = [f(x) for x in numpy.arange(X1, X2, 1e-2)]
            pyplot.plot(VerticalValues, HorizontalValues)
        
        elif (item.type == "Polynomial"):
            def f(x):
                s = 0
                coeffs = item.Coefficients
                for i in range(0, coeffs.__len__()):
                    s += coeffs[i] * (x**i)
                return s
            
            X1, X2 = 0, 0
            for i in range(7, -2, -1):
                while ((f(X1 - 10**i) >= infinite_Xmin_Poly) and (X1 - 10**i >= infinite_Xmin_Poly)):
                    X1 -= 10**i
                while ((f(X2 + 10**i) <= infinite_Xmax_Poly) and (X2 + 10**i <= infinite_Xmax_Poly)):
                    X2 += 10**i
            
            VerticalValues = [x for x in numpy.arange(X1, X2, 1e-2)]
            HorizontalValues = [f(x) for x in numpy.arange(X1, X2, 1e-2)]
            pyplot.plot(VerticalValues, HorizontalValues)

    def PlotAllVisibleItems(self):
        for item in self.items:
            if (item.isVisible):
                self.Plot(item)
        #pyplot.show(block = False)
        #pyplot.pause(1)
        
    def Zoom(self, Xmin, Xmax, Ymin, Ymax):
        if (Xmin < -1000): return
        if (Ymin < -1000): return
        if (Xmax > 1000): return
        if (Ymax > 1000): return
        pyplot.xlim(Xmin, Xmax)
        pyplot.ylim(Ymin, Ymax)
        self.Xmin = Xmin
        self.Xmax = Xmax
        self.Ymin = Ymin
        self.Ymax = Ymax
        #print(Xmin, Xmax, Ymin, Ymax)
        #pyplot.show(block = False)
        #pyplot.pause(1)
        
        
    def Simulate(self):
        #pyplot.grid()
        pyplot.xlabel("Horizontal (x)")
        pyplot.ylabel("Vertical (y)")
        
        for item in (self.items):
            if (item.isVisible):
                self.Plot(item)
        #pyplot.show(block = False)
        #pyplot.pause(1)
    
    def Clear(self):
        pyplot.cla()
        #pyplot.grid()
        pyplot.xlabel("Horizontal (x)")
        pyplot.ylabel("Vertical (y)")
        self.Zoom(-10, 10, -10, 10)
        pyplot.subplot(1, 1, 1)
        #pyplot.show(block = False)
        #pyplot.pause(1)
        
    
Surface = Space()

class Calc:
    def IntersectOf(d1, d, mode):
        if (mode == "Line-Line"):
            if (d1.A == d.A):
                if (d1.B == d.B):
                    return d1
                else:
                    return 0
            else:
                a1 = d1.A
                b1 = d1.B
                a2 = d.A
                b2 = d.B
                
                y = (b1*a2 - b2*a1) / (a2 - a1)
                x = (y - b1) / a1
                return Shapes.Point(x, y)        
        elif (mode == "Segment-Line"):
            return d1.Intersect(d, "Line")
        elif (mode == "Segment-Segment"):
            return d1.Intersect(d, "Segment")
    
    
    def Distance(obj1, obj2, indicator):
        if (indicator == "Point-Point"):
            return Shapes.Segment(obj1, obj2, "").Length()
        
        elif (indicator == "Point-Line"):
            PointA, Line_d = obj1, obj2
            x, y = PointA.X, PointA.Y
            a, b = Line_d.A, Line_d.B
            m, n, p = a, -1, b
            f = m*x + n*y + p
            module = sqrt(a*a + b*b)
            return (math.fabs(f)/module)
        
    def DotProduct(u, v):
        return (u.X*v.X + u.Y*v.Y)
    
    def VectorProduct(u, v):
        return (u.X*v.Y - v.X*u.Y)

#Point
class Shapes:
    global Surface
    class Point:
        global Surface
        
        def __init__(self, x, y, name):
            self.X = x
            self.Y = y
            self.type = "Point"
            self.isVisible = True
            if (name == ""):
                self.name = "Point(" + str(x) + "," + str(y) + ")"
            else:
                self.name = name

        def Rename(self, NewName):
            self.name = NewName
        
        def InsertToList(self):
            Surface.AddItem(self)
            
        def ToggleVisibility(self):
            VisibilityStatus = self.isVisible
            self.isVisible = not(VisibilityStatus)

    #Line - Segment - Vector
    class Line:
        global Surface
        
        #Công thức: y = Ax + B
        
        def __init__(self, A, VectorOrPoint, indicator, name):
            if (indicator == "Vector"):
                u = VectorOrPoint
                B = Point(A.X + u.X, A.Y + u.Y)
            elif (indicator == "Point"):
                B = VectorOrPoint
            
            deltaX = B.X - A.X
            deltaY = B.Y - A.Y
            a = deltaY/deltaX
            b = -(a*A.X - A.Y)
            
            self.A = a
            self.B = b
            self.type = "Line"
            self.isVisible = True
            if (name == ""):
                self.name = "Line(" + str(a) + "," + str(b) + ")"
            else:
                self.name = name
        
        def __init__(self, A, B, name):
            self.A = A
            self.B = B
            self.type = "Line"
            self.isVisible = True
            if (name == ""):
                self.name = "Line(" + str(A) + "," + str(B) + ")"
            else:
                self.name = name
        
        def InsertToList(self):
            Surface.AddItem(self)
        
        def ToggleVisibility(self):
            VisibilityStatus = self.isVisible
            self.isVisible = not(VisibilityStatus)

        def Rename(self, NewName):
            self.name = NewName
            

    class Segment:
        global Surface
        
        def __init__(self, A, B, name):
            self.type = "Segment"
            self.End1 = A
            self.End2 = B
            self.XLength = math.fabs(A.X - B.X)
            self.YLength = math.fabs(A.Y - B.Y)
            self.isVisible = True

            Name_A = "(" + str(A.X) + "," + str(A.Y) + ")"
            Name_B = "(" + str(B.X) + "," + str(B.Y) + ")"
            if (name == ""):
                self.name = "Segment(" + Name_A + "," + Name_B + ")"
            else:
                self.name = name
        
        def InsertToList(self):
            Surface.AddItem(self)   

        def Rename(self, NewName):
            self.name = NewName
        
        def ContainsPoint(self, M):
            A = self.End1
            B = self.End2
            return ((A.X <= M.X) and (M.X <= B.X))
        
        def Length(self):
            x = self.XLength
            y = self.YLength
            return (math.sqrt(x*x + y*y))
        
        def Line(self):
            return Line(self.End1, self.End2, "Point")
        
        def Intersect(self, obj, indicator):
            thisSegment = self
            if (indicator == Segment):
                A = Surface.IntersectOf(Line(thisSegment), Line(obj), "Line-Line")
                if (thisSegment.ContainsPoint(A) and obj.ContainsPoint(A)):
                    return A
                else:
                    return 0
            elif (indicator == Line):
                A = Surface.IntersectOf(Line(thisSegment), obj, "Line-Line")
                if (thisSegment.ContainsPoint(A)):
                    return A
                else:
                    return 0

        def ToggleVisibility(self):
            VisibilityStatus = self.isVisible
            self.isVisible = not(VisibilityStatus)
        
        
        
    class Vector(Point):
        global Surface

        def __init__(self, x, y, indicator, name):
            if (indicator == "Values"):
                self.X = x
                self.Y = y
                self.type = "Vector"
                self.isVisible = True
                
                if (name == ""):
                    self.name = "Vector(" + str(x) + "," + str(y) + ")"
                else:
                    self.name = name
                    
            elif (indicator == "Points"):
                A = x
                B = y
                self.X = B.X - A.X
                self.Y = B.Y - A.Y
                self.type = "Vector"
                self.isVisible = True
        
        def LengthVal(self):
            x, y = self.X, self.Y
            return math.sqrt(x*x + y*y)
        
        def AngleVal(self):
            x = self.X
            y = self.Y
            l = math.sqrt(x*x + y*y)
            return math.acos(x/l)
        
        def Segment(self, A):
            B = Point(A.X + self.X, A.Y + self.Y)
            return Segment(A, B, "")
        


    #Đa giác
    class Polygon:
        global Surface
        def __init__(self, ListOfPoints, NewName):
            self.ListOfPoints = ListOfPoints
            self.CyclicListOfPoints = ListOfPoints + [ListOfPoints[0]]
            self.N = ListOfPoints.__len__()
            self.type = "Polygon"
            self.isVisible = True
            
            self.ListOfContinuousVectors = []
            for i in range(0, self.CyclicListOfPoints.__len__() - 1):
                A = self.CyclicListOfPoints[i]
                B = self.CyclicListOfPoints[i+1]
                u = Shapes.Vector(B.X - A.X, B.Y - A.Y, "Values", "")
                self.ListOfContinuousVectors.append(u)

            def PointName(A):
                return "(" + str(A.X) + "," + str(A.Y) + ")"
            
            name = NewName
            if (name == ""):
                name = "Polygon("
                for A in ListOfPoints:
                    name += PointName(A) + ","
                name += ")"
            self.name = name
        
        def ToggleVisibility(self):
            VisibilityStatus = self.isVisible
            self.isVisible = not(VisibilityStatus)
            
        def isConvex(self):
            if (ListOfPoints.__len__() == 3): return True
            PointsList = ListOfPoints + ListOfPoints
            for i in range(0, ListOfPoints.__len__()):
                A = PointsList[i]
                B = PointsList[i+1]
                C = PointsList[i+2]
                D = PointsList[i+3]
                AB = Vector(A, B, "Values", "")
                BC = Vector(B, C, "Values", "")
                CD = Vector(C, D, "Values", "")
                S1 = Calc.VectorProduct(AB, BC)
                S2 = Calc.VectorProduct(BC, CD)
                if (S1*S2 < 0): return False
            return True
        
        def Area(self):
            if (self.isConvex):
                S = 0
                A = self.ListOfPoints[0]
                for i in range(1, self.N - 1):
                    B = self.ListOfPoints[i]
                    C = self.ListOfPoints[i+1]
                    AB = Shapes.Vector(A, B, "Points", "")
                    AC = Shapes.Vector(A, C, "Points", "")
                    S += math.fabs(Calc.VectorProduct(AB, AC)/2)
                return S
        
        def Rename(self, NewName):
            self.name = NewName
            
    class ConvexPolygon(Polygon):
        global Surface
        def Area(self):
            S = 0
            for i in range(1, self.N - 1):
                A = self.ListOfPoints[i-1]
                B = self.ListOfPoints[i]
                C = self.ListOfPoints[i+1]
                AB = Vector(A, B, "Points")
                AC = Vector(A, C, "Points")
                S += Surface.VectorProduct(AB, AC)/2
            return S
                

    class Triangle:
        def __init__(self, A, B, C, name):
            self.A = A
            self.B = B
            self.C = C
            self.isVisible = True
            self.type = "Triangle"

            def PointName(A):
                return "(" + str(A.X) + "," + str(A.Y) + ")"

            if (name == ""):
                self.name = "Triangle(" + PointName(A) + "," + PointName(B) + "," + PointName(C) + ")"
            else:
                self.name = name

            
        def ToggleVisibility(self):
            VisibilityStatus = self.isVisible
            self.isVisible = not(VisibilityStatus)

        def Rename(self, NewName):
            self.name = NewName
        
        def Perimeter(self):
            A = self.A
            B = self.B
            C = self.C
            AB = Segment(A, B)
            AC = Segment(A, C)
            BC = Segment(B, C)
            return (AB.Length() + BC.Length() + AC.Length())
            
        def Area(self):
            A = self.A
            B = self.B
            C = self.C
            AB = Shapes.Vector(A, B, "Points", "")
            AC = Shapes.Vector(A, C, "Points", "")
            S = math.fabs(Calc.VectorProduct(AB, AC) / 2)
            return S

    class Quadrilateral(ConvexPolygon):
        pass

    class Rectangle(Quadrilateral):
        def __init__(self, Point, w, l):
            pass
        
        def Area(self):
            return (self.w)*(self.l)

    class Square(Rectangle):
        pass
        
    #Đường tròn - Parabol - Hàm bậc 3
    class Circle:
        global Surface
        def __init__(self, O, R, name):
            self.Center = O
            self.R = R
            self.type = "Circle"
            self.isVisible = True

            def PointName(A):
                return "(" + str(A.X) + "," + str(A.Y) + ")"
            if (name == ""):
                self.name = "Circle(" + PointName(O) + "," + str(R) + ")"
            else:
                self.name = name
        
        def ToggleVisibility(self):
            self.isVisible = not(self.isVisible)

        def Rename(self, NewName):
            self.name = NewName
            
        def Perimeter(self):
            return 2*(math.pi)*R
        def Area(self):
            return (math.pi)*R*R
        
    class Parabol:
        global Surface
        def __init__(self, A, B, C, name):
            self.A = A
            self.B = B
            self.C = C
            self.type = "Parabol"
            self.isVisible = True
            if (name == ""):
                self.name = "Parabol(" + str(A) + "," + str(B) + "," + str(C) + ")"
            else:
                self.name = name
        
        def Derivative(self):
            return Line(2*A, B)
        
        def Area(self, x, y):
            pass
        
        def ToggleVisibility(self):
            self.isVisible = not(self.isVisible)

        def Rename(self, NewName):
            self.name = NewName
    
    class TrajectoryOfCubicFunctions:
        global Surface
        def __init__(self, A, B, C, D):
            self.A = A
            self.B = B
            self.C = C
            self.D = D
            self.type = "Cubic"
            self.isVisible = True
            self.name = "CubicFunc(" + str(A) + "," + str(B) + "," + str(C) + "," + str(D) + ")"
        
        def Derivative(self):
            return Parabol(3*A, 2*B, C)
        
        def ToggleVisibility(self):
            self.isVisible = not(self.isVisible)

        def Rename(self, NewName):
            self.name = NewName
    
    class Polynomial:
        global Surface
        def __init__(self, Coefficients, NewName):
            self.Coefficients = Coefficients
            self.type = "Polynomial"
            self.isVisible = True

            name = NewName
            if (name == ""):
                name = "Polynomial("
                for x in Coefficients:
                    name += x + ","
                name += ")"
            self.name = name

        def Rename(self, NewName):
            self.name = NewName
            
        def Derivative(self):
            NewCoeffs = [i*(self.Coefficients[i]) for i in range(1, self.Coefficients.__len__())]
            return Polynomial(NewCoeffs)
        
        def AntiDerivative(self, C):
            NewCoeffs = [C] + NewCoeffs
            for i in range(1, NewCoeffs.__len__()):
                NewCoeffs = i*NewCoeffs
            return Polynomial(NewCoeffs)
        
        def ToggleVisibility(self):
            self.isVisible = not(self.isVisible)
    
class CodeTranslation:
    global Surface
    def Def(code):
        words = [word for word in code.split(" ") if word]
        objnames = words[0].split("_")
        objs = [Surface.FindItem(itemname) for itemname in objnames]
        
        if (words[1] == "Distance"):
            return str(Calc.Distance(objs[0], objs[1], "Point-Point"))
        elif (words[1] == "Length"):
            return str(objs[0].Length)
        elif (words[1] == "Const_A"):
            return str(objs[0].A)
        elif (words[1] == "Const_B"):
            return str(objs[0].B)
        elif (words[1] == "Const_Center"):
            return str(objs[0].Center)
        elif (words[1] == "Const_R"):
            return str(objs[0].R)
        elif (words[1] == "Const_D"):
            return str(2*objs[0].R)
        elif (words[1] == "Perimeter"):
            return str(objs[0].Perimeter())
        elif (words[1] == "Area"):
            return str(objs[0].Area())
        
        return "!"
    
    def PolynomialTranslation(code):
        words = [word for word in code.replace("[", "").replace("]", "").split(" ") if word]
        name = words[0]

        coeffs = [0 for i in range(0, int(words[1]) + 1)]
        for i in range(1, words.__len__(), 2):
            coeffs[int(words[i])] = float(words[i+1])

        return Shapes.Polynomial(coeffs, name)
    
    def PolygonCodeTranslation(code):
        words = [word for word in code.replace("[", "").replace("]", "").split(" ") if word]
        name = words[0]
        words.pop(0)
        PolygonPoints = [Surface.FindItem(word) for word in words]
        return Shapes.Polygon(PolygonPoints, name)


'''
A = Shapes.Point(0, 0, "A")
B = Shapes.Point(3, 2, "B")
C = Shapes.Point(4, 0, "C")
D = Shapes.Point(2, -2, "D")
ABCD = Shapes.Polygon([A, B, C, D], "ABCD")
print(ABCD.Area())
'''
