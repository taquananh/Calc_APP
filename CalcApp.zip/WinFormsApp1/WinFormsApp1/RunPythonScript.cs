﻿using System;
using Microsoft.VisualBasic.ApplicationServices;
using Python.Runtime;
using static IronPython.Modules._ast;

public class RunPythonScript
{
	public RunPythonScript()
	{
        
    }
    public void RunScript()
    {
        Runtime.PythonDLL = "C:\\Users\\dell\\AppData\\Local\\Programs\\Python\\Python311\\python311.dll";
        PythonEngine.Initialize();
    }

    public dynamic OpenClosePlot()
    {
        using (Py.GIL())
        {
            dynamic sys = Py.Import("sys");
            sys.path.append("C:\\Users\\dell\\source\\repos\\WinFormsApp1\\WinFormsApp1");
            return Py.Import("OpenNClosePlot");
        }

    }

    public dynamic Plotting()
    {
        using (Py.GIL())
        {
            dynamic sys = Py.Import("sys");
            sys.path.append("C:\\Users\\dell\\source\\repos\\WinFormsApp1\\WinFormsApp1");
            return Py.Import("Plotting");
        }
    }
}
