﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalcApp
{
    public partial class CalcHelp : Form
    {
        public CalcHelp()
        {
            InitializeComponent();
            
        }

        public void CalcHelp_Load(object sender, EventArgs e)
        {
            var sb = new StringBuilder();
            //sb.Append(@"{\rtf1\ansi");
            /***
            sb.Append(@"\b I. Cú pháp tổng quát \b0 \n");
            sb.Append(@"Muốn tính thuộc tính của một hình, sử dụng cú pháp: \n");
            sb.Append(@"<Tên hình> <Mã đại lượng> \n");
            sb.Append(@"Ví dụ: tính diện tích tam giác 'ABC': \n");
            sb.Append(@"ABC Area \n\n");
            sb.Append(@"Muốn tính thuộc tính liên quan đến hai hình, sử dụng cú pháp: \n");
            sb.Append(@"<Tên hình 1>_<Tên hình 2> <Mã đại lượng> \n");
            sb.Append(@"Ví dụ: tính khoảng cách giữa hai điểm M, N: \n");
            sb.Append(@"M_N Distance \n\n\n");

            sb.Append(@"\b II. Các mã đại lượng \b0 \n");
            sb.Append(@"\i 1. Điểm \i0 \n");
            sb.Append(@"Distance - Khoảng cách \n");

            sb.Append(@"\i 2. Đường thẳng \i0 \n");
            sb.Append(@"Const_A - Hệ số a \n");
            sb.Append(@"Const_B - Hệ số b \n");
            sb.Append(@"Const_Angle - Hệ số góc \n");

            sb.Append(@"\i 3. Đường tròn \i0 \n");
            sb.Append(@"Const_Center - Tâm \n");
            sb.Append(@"Const_R - Bán kính \n");
            sb.Append(@"Const_D - Đường kính \n");
            sb.Append(@"Perimeter - Chu vi \n");
            sb.Append(@"Area - Diện tích \n");
            sb.Append(@"}");
            richTextBox1.Text = sb.ToString();
            ***/
        }
    }
}
