﻿namespace CalcApp
{
    partial class AddPointDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Confirm = new Button();
            label1 = new Label();
            label2 = new Label();
            groupBox1 = new GroupBox();
            NameBox = new TextBox();
            label3 = new Label();
            yValueBox = new TextBox();
            xValueBox = new TextBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // Confirm
            // 
            Confirm.Location = new Point(169, 144);
            Confirm.Name = "Confirm";
            Confirm.Size = new Size(94, 29);
            Confirm.TabIndex = 0;
            Confirm.Text = "OK";
            Confirm.UseVisualStyleBackColor = true;
            Confirm.Click += Confirm_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 23);
            label1.Name = "label1";
            label1.Size = new Size(112, 20);
            label1.TabIndex = 1;
            label1.Text = "Nhập hoành độ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 56);
            label2.Name = "label2";
            label2.Size = new Size(101, 20);
            label2.TabIndex = 2;
            label2.Text = "Nhập tung độ";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(NameBox);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(yValueBox);
            groupBox1.Controls.Add(xValueBox);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(251, 126);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thêm điểm";
            // 
            // NameBox
            // 
            NameBox.Location = new Point(119, 86);
            NameBox.Name = "NameBox";
            NameBox.Size = new Size(125, 27);
            NameBox.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 89);
            label3.Name = "label3";
            label3.Size = new Size(70, 20);
            label3.TabIndex = 4;
            label3.Text = "Nhập tên";
            // 
            // yValueBox
            // 
            yValueBox.Location = new Point(119, 53);
            yValueBox.Name = "yValueBox";
            yValueBox.Size = new Size(125, 27);
            yValueBox.TabIndex = 3;
            // 
            // xValueBox
            // 
            xValueBox.Location = new Point(119, 20);
            xValueBox.Name = "xValueBox";
            xValueBox.Size = new Size(125, 27);
            xValueBox.TabIndex = 2;
            // 
            // AddPointDialog
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(276, 181);
            Controls.Add(groupBox1);
            Controls.Add(Confirm);
            Name = "AddPointDialog";
            Text = "Thêm điểm...";
            Load += AddPointDialog_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button Confirm;
        private Label label1;
        private Label label2;
        private GroupBox groupBox1;
        private TextBox yValueBox;
        private TextBox xValueBox;
        private TextBox NameBox;
        private Label label3;
    }
}