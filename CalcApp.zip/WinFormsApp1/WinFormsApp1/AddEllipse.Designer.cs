﻿namespace CalcApp
{
    partial class AddEllipse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textBox10 = new TextBox();
            label10 = new Label();
            textBox9 = new TextBox();
            label9 = new Label();
            textBox6 = new TextBox();
            label6 = new Label();
            textBox5 = new TextBox();
            label5 = new Label();
            textBox3 = new TextBox();
            label2 = new Label();
            textBox4 = new TextBox();
            button1 = new Button();
            label1 = new Label();
            groupBox2 = new GroupBox();
            textBox8 = new TextBox();
            label8 = new Label();
            textBox7 = new TextBox();
            label7 = new Label();
            textBox2 = new TextBox();
            label3 = new Label();
            textBox1 = new TextBox();
            button2 = new Button();
            label4 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox10);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(textBox9);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(textBox6);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(textBox5);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(textBox4);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 7);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(377, 265);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thêm elip";
            // 
            // textBox10
            // 
            textBox10.Location = new Point(241, 191);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(125, 27);
            textBox10.TabIndex = 17;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(6, 194);
            label10.Name = "label10";
            label10.Size = new Size(229, 20);
            label10.TabIndex = 16;
            label10.Text = "Nhập vế phải (số thực không âm)";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(241, 158);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(125, 27);
            textBox9.TabIndex = 15;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(6, 161);
            label9.Name = "label9";
            label9.Size = new Size(122, 20);
            label9.TabIndex = 14;
            label9.Text = "Nhập hệ số của y";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(241, 125);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(125, 27);
            textBox6.TabIndex = 13;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 128);
            label6.Name = "label6";
            label6.Size = new Size(122, 20);
            label6.TabIndex = 12;
            label6.Text = "Nhập hệ số của x";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(241, 92);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(125, 27);
            textBox5.TabIndex = 11;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 95);
            label5.Name = "label5";
            label5.Size = new Size(211, 20);
            label5.TabIndex = 10;
            label5.Text = "Nhập hệ số của bình phương y";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(241, 56);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(125, 27);
            textBox3.TabIndex = 9;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 59);
            label2.Name = "label2";
            label2.Size = new Size(129, 20);
            label2.TabIndex = 8;
            label2.Text = "Nhập hệ số của xy";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(241, 20);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(125, 27);
            textBox4.TabIndex = 7;
            // 
            // button1
            // 
            button1.Location = new Point(272, 224);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 4;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 23);
            label1.Name = "label1";
            label1.Size = new Size(211, 20);
            label1.TabIndex = 1;
            label1.Text = "Nhập hệ số của bình phương x";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(textBox8);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(textBox7);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(textBox2);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(textBox1);
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(label4);
            groupBox2.Location = new Point(12, 278);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(377, 191);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thêm đường tròn";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(177, 118);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(189, 27);
            textBox8.TabIndex = 10;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(7, 121);
            label8.Name = "label8";
            label8.Size = new Size(152, 20);
            label8.TabIndex = 9;
            label8.Text = "Nhập độ dài bán kính";
            // 
            // textBox7
            // 
            textBox7.Location = new Point(177, 85);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(189, 27);
            textBox7.TabIndex = 8;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(7, 88);
            label7.Name = "label7";
            label7.Size = new Size(100, 20);
            label7.TabIndex = 7;
            label7.Text = "Nhập tên tâm";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(177, 52);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(189, 27);
            textBox2.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(7, 55);
            label3.Name = "label3";
            label3.Size = new Size(131, 20);
            label3.TabIndex = 5;
            label3.Text = "Nhập tung độ tâm";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(177, 20);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(189, 27);
            textBox1.TabIndex = 3;
            // 
            // button2
            // 
            button2.Location = new Point(272, 151);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 4;
            button2.Text = "OK";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(7, 23);
            label4.Name = "label4";
            label4.Size = new Size(142, 20);
            label4.TabIndex = 1;
            label4.Text = "Nhập hoành độ tâm";
            // 
            // AddEllipse
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(401, 481);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "AddEllipse";
            Text = "Thêm elip/đường tròn";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button button1;
        private Label label1;
        private GroupBox groupBox2;
        private TextBox textBox1;
        private Button button2;
        private Label label4;
        private TextBox textBox6;
        private Label label6;
        private TextBox textBox5;
        private Label label5;
        private TextBox textBox3;
        private Label label2;
        private TextBox textBox4;
        private TextBox textBox8;
        private Label label8;
        private TextBox textBox7;
        private Label label7;
        private TextBox textBox2;
        private Label label3;
        private TextBox textBox10;
        private Label label10;
        private TextBox textBox9;
        private Label label9;
    }
}