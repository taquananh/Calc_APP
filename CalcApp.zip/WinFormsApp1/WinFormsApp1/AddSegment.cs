﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1;

namespace CalcApp
{
    public partial class AddSegment : Form
    {
        public AddSegment()
        {
            InitializeComponent();
        }

        private void Confirm_Click(object sender, EventArgs e)
        {
            Form1.NewSegment(Point1.Text, Point2.Text, SegmentName.Text);
        }
    }
}
