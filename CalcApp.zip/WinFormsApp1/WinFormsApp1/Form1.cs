﻿using CalcApp;
using System.Windows.Forms;
using Python.Runtime;
using static Python.Runtime.TypeSpec;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Globalization;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public static Form1 MainForm;
        public Form1()
        {
            MainForm = this;
            InitializeComponent();
        }

        public RunPythonScript RPS = new RunPythonScript();
        public static dynamic OCP, Plotting, Space;
        public static dynamic Surface;
        public static dynamic Plot;

        private void Form1_Load(object sender, EventArgs e)
        {
            RPS.RunScript();
            OCP = RPS.OpenClosePlot();
            Plotting = RPS.Plotting();
            Surface = Plotting.Space();

            using (Py.GIL())
            {
                Plot = (new Pyplot()).pyplot();
                //Plot.plot(0, 0, 'o');
                OCP.InvokeMethod("ShowPlot");
            }
            //tabPage1.Container.Add(Plot);
        }

        private void tabPage1_Click(object sender, EventArgs e)
        { }

        static public void NewItems(object itemname)
        {
            MainForm.ModifyShapeComboBox.Items.Add(itemname);

            //dynamic itemslist = new Form1().ModifyShapeComboBox.Items;
            //itemslist.Add(itemname);
        }

        static public void NewSegment(string point1, string point2, string name)
        {
            MainForm.ModifyShapeComboBox.Items.Add(name);

            using (Py.GIL())
            {
                dynamic A = Surface.InvokeMethod("FindItem", new PyObject[] { new PyString(point1) });
                dynamic B = Surface.InvokeMethod("FindItem", new PyObject[] { new PyString(point2) });

                dynamic AB = Plotting.Shapes.Segment(A, B, name);
                Form1.Surface.InvokeMethod("AddItem", new PyObject[] { AB });
                Form1.Surface.InvokeMethod("Plot", new PyObject[] { AB });
                OCP.ShowPlot();

                string objname = AB.name;
                Form1.NewItems(objname);
            }

            //dynamic itemslist = new Form1().ModifyShapeComboBox.Items;
            //itemslist.Add(itemname);
        }

        private void AddPointToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new AddPointDialog().Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            /**
            dynamic OCP = RPS.OpenClosePlot();

            using (Py.GIL())
            {
                dynamic Plot = (new Pyplot()).pyplot();
                Plot.plot(2, 3, 'o');
                OCP.InvokeMethod("ShowPlot");
            }
            **/
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void ZoomConfirmation_Click(object sender, EventArgs e)
        {
            float float1, float2, float3, float4;
            bool check1, check2, check3, check4;
            check1 = float.TryParse(xMin.Text, out float1);
            check2 = float.TryParse(xMax.Text, out float2);
            check3 = float.TryParse(yMin.Text, out float3);
            check4 = float.TryParse(yMax.Text, out float4);

            if (check1 && check2 && check3 && check4)
                using (Py.GIL())
                {
                    PyFloat xm = new PyFloat(float1);
                    PyFloat xM = new PyFloat(float2);
                    PyFloat ym = new PyFloat(float3);
                    PyFloat yM = new PyFloat(float4);

                    Surface.InvokeMethod("Zoom", new PyObject[] { xm, xM, ym, yM });
                    OCP.ShowPlot();
                }
        }

        private void AddShapeConfirmation_Click(object sender, EventArgs e)
        {
            /***
            if (AddShapeComboBox.Text == "Điểm")
                new AddPointDialog().Show();
            else if (AddShapeComboBox.Text == "Đường thẳng/Hàm đa thức")
                new AddPolynomial().Show();
            ***/
        }

        private void button8_Click(object sender, EventArgs e)
        {
            CalcHelp CH = new CalcHelp();
            CH.Show();
        }

        private void đườngTrònElipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new AddCircle().Show();
        }

        private void AddPolynomialToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new AddPolynomial().Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //tester
        }

        private void ToggleVisibility_Click(object sender, EventArgs e)
        {
            PyString itemname = new PyString(ModifyShapeComboBox.Text);
            using (Py.GIL())
            {
                dynamic item = Surface.InvokeMethod("FindItem", new PyObject[] { itemname });
                item.ToggleVisibility();
                Surface.InvokeMethod("Clear");
                Surface.InvokeMethod("PlotAllVisibleItems");
                OCP.ShowPlot();
            }
        }

        private void RemoveItem_Click(object sender, EventArgs e)
        {
            PyString itemname = new PyString(ModifyShapeComboBox.Text);
            MainForm.ModifyShapeComboBox.Items.Remove(ModifyShapeComboBox.Text);
            using (Py.GIL())
            {
                dynamic item = Surface.InvokeMethod("RemoveItem", new PyObject[] { itemname });
                Surface.InvokeMethod("Clear");
                Surface.InvokeMethod("PlotAllVisibleItems");
                OCP.ShowPlot();
            }
        }

        private void CodeConfirm_Click(object sender, EventArgs e)
        {
            PyString Code = new PyString(CodeBox.Text);
            using (Py.GIL())
            {
                PyString PyAns = new PyString(Plotting.CodeTranslation.InvokeMethod("Def", new PyObject[] { Code }));
                string ans = PyAns.ToString();
                ResultBox.Text = ans;
            }
        }

        private void đaGiácToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new AddPolygon().Show();
        }

        private void đToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new AddSegment().Show();
        }
    }
}
