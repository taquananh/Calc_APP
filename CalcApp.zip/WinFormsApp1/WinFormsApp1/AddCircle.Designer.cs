﻿namespace CalcApp
{
    partial class AddCircle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label4 = new Label();
            CenterNameText = new TextBox();
            label7 = new Label();
            yValue = new TextBox();
            label3 = new Label();
            xValue = new TextBox();
            RadiusText = new TextBox();
            groupBox2 = new GroupBox();
            CircleNameText = new TextBox();
            label1 = new Label();
            label8 = new Label();
            Confirm = new Button();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(7, 23);
            label4.Name = "label4";
            label4.Size = new Size(142, 20);
            label4.TabIndex = 1;
            label4.Text = "Nhập hoành độ tâm";
            // 
            // CenterNameText
            // 
            CenterNameText.Location = new Point(271, 85);
            CenterNameText.Name = "CenterNameText";
            CenterNameText.Size = new Size(260, 27);
            CenterNameText.TabIndex = 8;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(7, 88);
            label7.Name = "label7";
            label7.Size = new Size(216, 20);
            label7.TabIndex = 7;
            label7.Text = "Nhập tên tâm (có thể để trống)";
            // 
            // yValue
            // 
            yValue.Location = new Point(271, 52);
            yValue.Name = "yValue";
            yValue.Size = new Size(260, 27);
            yValue.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(7, 55);
            label3.Name = "label3";
            label3.Size = new Size(131, 20);
            label3.TabIndex = 5;
            label3.Text = "Nhập tung độ tâm";
            // 
            // xValue
            // 
            xValue.Location = new Point(271, 20);
            xValue.Name = "xValue";
            xValue.Size = new Size(260, 27);
            xValue.TabIndex = 3;
            // 
            // RadiusText
            // 
            RadiusText.Location = new Point(271, 118);
            RadiusText.Name = "RadiusText";
            RadiusText.Size = new Size(260, 27);
            RadiusText.TabIndex = 10;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(CircleNameText);
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(RadiusText);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(CenterNameText);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(yValue);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(xValue);
            groupBox2.Controls.Add(Confirm);
            groupBox2.Controls.Add(label4);
            groupBox2.Location = new Point(12, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(543, 225);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thêm đường tròn";
            // 
            // CircleNameText
            // 
            CircleNameText.Location = new Point(271, 153);
            CircleNameText.Name = "CircleNameText";
            CircleNameText.Size = new Size(260, 27);
            CircleNameText.TabIndex = 12;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(7, 156);
            label1.Name = "label1";
            label1.Size = new Size(149, 20);
            label1.TabIndex = 11;
            label1.Text = "Nhập tên đường tròn";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(7, 121);
            label8.Name = "label8";
            label8.Size = new Size(152, 20);
            label8.TabIndex = 9;
            label8.Text = "Nhập độ dài bán kính";
            // 
            // Confirm
            // 
            Confirm.Location = new Point(271, 186);
            Confirm.Name = "Confirm";
            Confirm.Size = new Size(260, 29);
            Confirm.TabIndex = 4;
            Confirm.Text = "OK";
            Confirm.UseVisualStyleBackColor = true;
            Confirm.Click += Confirm_Click;
            // 
            // AddCircle
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(567, 247);
            Controls.Add(groupBox2);
            Name = "AddCircle";
            Text = "AddCircle";
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label4;
        private TextBox CenterNameText;
        private Label label7;
        private TextBox yValue;
        private Label label3;
        private TextBox xValue;
        private TextBox RadiusText;
        private GroupBox groupBox2;
        private TextBox CircleNameText;
        private Label label1;
        private Label label8;
        private Button Confirm;
    }
}