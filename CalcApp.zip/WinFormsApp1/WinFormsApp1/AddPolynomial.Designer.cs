﻿namespace CalcApp
{
    partial class AddPolynomial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LnConfirmation = new Button();
            label2 = new Label();
            label1 = new Label();
            groupBox1 = new GroupBox();
            LnName = new TextBox();
            label6 = new Label();
            BLn = new TextBox();
            ALn = new TextBox();
            ParabolConfirmation = new Button();
            groupBox2 = new GroupBox();
            PrName = new TextBox();
            label7 = new Label();
            CPr = new TextBox();
            label5 = new Label();
            BPr = new TextBox();
            APr = new TextBox();
            label3 = new Label();
            label4 = new Label();
            groupBox3 = new GroupBox();
            PolynomialConfirmation = new Button();
            PolynomialCode = new RichTextBox();
            label8 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // LnConfirmation
            // 
            LnConfirmation.Location = new Point(151, 119);
            LnConfirmation.Name = "LnConfirmation";
            LnConfirmation.Size = new Size(94, 29);
            LnConfirmation.TabIndex = 4;
            LnConfirmation.Text = "OK";
            LnConfirmation.UseVisualStyleBackColor = true;
            LnConfirmation.Click += LnConfirmation_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 56);
            label2.Name = "label2";
            label2.Size = new Size(87, 20);
            label2.TabIndex = 2;
            label2.Text = "Hệ số tự do";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 23);
            label1.Name = "label1";
            label1.Size = new Size(85, 20);
            label1.TabIndex = 1;
            label1.Text = "Hệ số của x";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(LnName);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(BLn);
            groupBox1.Controls.Add(ALn);
            groupBox1.Controls.Add(LnConfirmation);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(251, 157);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thêm đường thẳng";
            // 
            // LnName
            // 
            LnName.Location = new Point(114, 86);
            LnName.Name = "LnName";
            LnName.Size = new Size(130, 27);
            LnName.TabIndex = 6;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 89);
            label6.Name = "label6";
            label6.Size = new Size(32, 20);
            label6.TabIndex = 5;
            label6.Text = "Tên";
            // 
            // BLn
            // 
            BLn.Location = new Point(114, 53);
            BLn.Name = "BLn";
            BLn.Size = new Size(130, 27);
            BLn.TabIndex = 3;
            // 
            // ALn
            // 
            ALn.Location = new Point(114, 20);
            ALn.Name = "ALn";
            ALn.Size = new Size(130, 27);
            ALn.TabIndex = 2;
            // 
            // ParabolConfirmation
            // 
            ParabolConfirmation.Location = new Point(151, 155);
            ParabolConfirmation.Name = "ParabolConfirmation";
            ParabolConfirmation.Size = new Size(94, 29);
            ParabolConfirmation.TabIndex = 6;
            ParabolConfirmation.Text = "OK";
            ParabolConfirmation.UseVisualStyleBackColor = true;
            ParabolConfirmation.Click += ParabolConfirmation_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(PrName);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(CPr);
            groupBox2.Controls.Add(ParabolConfirmation);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(BPr);
            groupBox2.Controls.Add(APr);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label4);
            groupBox2.Location = new Point(12, 175);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(251, 196);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thêm parabol";
            // 
            // PrName
            // 
            PrName.Location = new Point(114, 122);
            PrName.Name = "PrName";
            PrName.Size = new Size(130, 27);
            PrName.TabIndex = 8;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 125);
            label7.Name = "label7";
            label7.Size = new Size(32, 20);
            label7.TabIndex = 7;
            label7.Text = "Tên";
            // 
            // CPr
            // 
            CPr.Location = new Point(114, 89);
            CPr.Name = "CPr";
            CPr.Size = new Size(130, 27);
            CPr.TabIndex = 5;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 92);
            label5.Name = "label5";
            label5.Size = new Size(87, 20);
            label5.TabIndex = 4;
            label5.Text = "Hệ số tự do";
            label5.Click += label5_Click;
            // 
            // BPr
            // 
            BPr.Location = new Point(114, 53);
            BPr.Name = "BPr";
            BPr.Size = new Size(130, 27);
            BPr.TabIndex = 3;
            // 
            // APr
            // 
            APr.Location = new Point(114, 20);
            APr.Name = "APr";
            APr.Size = new Size(130, 27);
            APr.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 56);
            label3.Name = "label3";
            label3.Size = new Size(87, 20);
            label3.TabIndex = 2;
            label3.Text = "Hệ số bậc 1";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 23);
            label4.Name = "label4";
            label4.Size = new Size(87, 20);
            label4.TabIndex = 1;
            label4.Text = "Hệ số bậc 2";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(PolynomialConfirmation);
            groupBox3.Controls.Add(PolynomialCode);
            groupBox3.Controls.Add(label8);
            groupBox3.Location = new Point(275, 12);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(251, 359);
            groupBox3.TabIndex = 8;
            groupBox3.TabStop = false;
            groupBox3.Text = "Hàm đa thức khác";
            // 
            // PolynomialConfirmation
            // 
            PolynomialConfirmation.Location = new Point(151, 318);
            PolynomialConfirmation.Name = "PolynomialConfirmation";
            PolynomialConfirmation.Size = new Size(94, 29);
            PolynomialConfirmation.TabIndex = 9;
            PolynomialConfirmation.Text = "OK";
            PolynomialConfirmation.UseVisualStyleBackColor = true;
            PolynomialConfirmation.Click += PolynomialConfirmation_Click;
            // 
            // PolynomialCode
            // 
            PolynomialCode.Location = new Point(9, 130);
            PolynomialCode.Name = "PolynomialCode";
            PolynomialCode.Size = new Size(236, 182);
            PolynomialCode.TabIndex = 2;
            PolynomialCode.Text = "";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 23);
            label8.Name = "label8";
            label8.Size = new Size(223, 100);
            label8.TabIndex = 1;
            label8.Text = "Nhập tên đa thức, các hệ số đa \r\nthức vào ô dưới đây theo mẫu:\r\n[Tên] [Bậc_của_hạng_tử] Hệ số\r\nVí dụ, nhập f: y = 4x + 5 như sau:\r\n[f] [1] 4 [0] 5 ";
            label8.Click += label8_Click;
            // 
            // AddPolynomial
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(537, 382);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "AddPolynomial";
            Text = "Thêm quỹ tích hàm đa thức";
            Load += AddPolynomial_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button LnConfirmation;
        private Label label2;
        private Label label1;
        private GroupBox groupBox1;
        private TextBox BLn;
        private TextBox ALn;
        private Button ParabolConfirmation;
        private GroupBox groupBox2;
        private TextBox BPr;
        private TextBox APr;
        private Label label3;
        private Label label4;
        private TextBox CPr;
        private Label label5;
        private GroupBox groupBox3;
        private Label label8;
        private Button PolynomialConfirmation;
        private RichTextBox PolynomialCode;
        private TextBox LnName;
        private Label label6;
        private TextBox PrName;
        private Label label7;
    }
}