import matplotlib.pyplot as pyplot

def ShowPlot():
    #pyplot.grid()
    pyplot.show(block = False)
    #pyplot.pause(1)
    figure = pyplot.figure()
    pyplot.close(figure)
