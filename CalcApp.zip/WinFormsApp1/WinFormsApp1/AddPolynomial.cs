﻿using Python.Runtime;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1;

namespace CalcApp
{
    public partial class AddPolynomial : Form
    {
        public AddPolynomial()
        {
            InitializeComponent();
        }

        public RunPythonScript RPS = new RunPythonScript();
        public dynamic OCP, Plotting, Space;
        public dynamic Plot = (new Pyplot()).pyplot();
        private void AddPolynomial_Load(object sender, EventArgs e)
        {
            OCP = RPS.OpenClosePlot();
            Plotting = RPS.Plotting();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void LnConfirmation_Click(object sender, EventArgs e)
        {
            if
                (
                    StringToFloat.isConvertible(ALn.Text) &&
                    StringToFloat.isConvertible(BLn.Text)
                )
            {
                float A = StringToFloat.Float(ALn.Text);
                float B = StringToFloat.Float(BLn.Text);
                PyString name = new PyString(LnName.Text);
                PyObject d = Form1.Plotting.Shapes().Line(A, B, name);


                Form1.Surface.AddItem(d);
                Form1.Surface.Plot(d);
                Form1.OCP.ShowPlot();
                //Form1.Plot.plot(new object[] { 2, 3 }, new object[] { 2, 3 });

                dynamic d_dynamic = d;
                string LineName = d_dynamic.name;
                Form1.NewItems(LineName);
            }
        }

        private void ParabolConfirmation_Click(object sender, EventArgs e)
        {
            if
                (
                    StringToFloat.isConvertible(APr.Text) &&
                    StringToFloat.isConvertible(BPr.Text) &&
                    StringToFloat.isConvertible(CPr.Text)
                )
            {
                float A = StringToFloat.Float(APr.Text);
                float B = StringToFloat.Float(BPr.Text);
                float C = StringToFloat.Float(CPr.Text);
                PyString name = new PyString(PrName.Text);
                PyObject d = Form1.Plotting.Shapes().Parabol(A, B, C, name);

                Form1.Surface.AddItem(d);
                Form1.Surface.Plot(d);
                Form1.OCP.ShowPlot();

                dynamic d_dynamic = d;
                string ParabolName = d_dynamic.name;
                Form1.NewItems(ParabolName);
                //Form1.Plot.plot(new object[] { 2, 3 }, new object[] { 2, 3 });
            }
        }

        private void PolynomialConfirmation_Click(object sender, EventArgs e)
        {
            using (Py.GIL())
            {
                dynamic Polynomial = Form1.Plotting.CodeTranslation.PolynomialTranslation(PolynomialCode.Text);
                PyObject PyPo = Polynomial;
                Form1.Surface.InvokeMethod("AddItem", new PyObject[] { PyPo });
                Form1.Surface.InvokeMethod("Plot", new PyObject[] { PyPo });
                OCP.ShowPlot();

                string objname = Polynomial.name;
                Form1.NewItems(objname);
            }
        }

        
    }
}
