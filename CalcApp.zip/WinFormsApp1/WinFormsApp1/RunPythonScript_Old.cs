﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;
using Python.Runtime;

public class RunPythonScript_Old
{
    public dynamic pyplot()
    {
        return Py.Import("matplotlib.pyplot");
    }

	public RunPythonScript_Old()
	{
        Runtime.PythonDLL = "C:\\Users\\dell\\AppData\\Local\\Programs\\Python\\Python311\\python311.dll";
        PythonEngine.Initialize();
        using (Py.GIL())
        {
            var fig = pyplot().figure();
            var ax = pyplot().subplot(111);

            //(var fig, var ax) = pyplot.subplots(figsize: new List<double> {1, 1}, dpi: dpi);
            ax.plot(2, 2, 'o', color: "r");
            pyplot().show();
        }
    }
}
