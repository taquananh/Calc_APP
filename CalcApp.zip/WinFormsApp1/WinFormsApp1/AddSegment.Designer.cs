﻿namespace CalcApp
{
    partial class AddSegment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            Point1 = new TextBox();
            Point2 = new TextBox();
            Confirm = new Button();
            SegmentName = new TextBox();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 15);
            label1.Name = "label1";
            label1.Size = new Size(82, 20);
            label1.TabIndex = 0;
            label1.Text = "Tên điểm 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 48);
            label2.Name = "label2";
            label2.Size = new Size(82, 20);
            label2.TabIndex = 1;
            label2.Text = "Tên điểm 2";
            // 
            // Point1
            // 
            Point1.Location = new Point(100, 12);
            Point1.Name = "Point1";
            Point1.Size = new Size(125, 27);
            Point1.TabIndex = 2;
            // 
            // Point2
            // 
            Point2.Location = new Point(100, 45);
            Point2.Name = "Point2";
            Point2.Size = new Size(125, 27);
            Point2.TabIndex = 3;
            // 
            // Confirm
            // 
            Confirm.Location = new Point(131, 111);
            Confirm.Name = "Confirm";
            Confirm.Size = new Size(94, 29);
            Confirm.TabIndex = 4;
            Confirm.Text = "OK";
            Confirm.UseVisualStyleBackColor = true;
            Confirm.Click += Confirm_Click;
            // 
            // SegmentName
            // 
            SegmentName.Location = new Point(100, 78);
            SegmentName.Name = "Name";
            SegmentName.Size = new Size(125, 27);
            SegmentName.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 81);
            label3.Name = "label3";
            label3.Size = new Size(70, 20);
            label3.TabIndex = 5;
            label3.Text = "Tên đoạn";
            // 
            // AddSegment
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(237, 147);
            Controls.Add(SegmentName);
            Controls.Add(label3);
            Controls.Add(Confirm);
            Controls.Add(Point2);
            Controls.Add(Point1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddSegment";
            Text = "AddSegment";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox Point1;
        private TextBox Point2;
        private Button Confirm;
        private TextBox SegmentName;
        private Label label3;
    }
}