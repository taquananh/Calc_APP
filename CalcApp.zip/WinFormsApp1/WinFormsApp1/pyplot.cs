﻿using System;
using Python.Runtime;

public class Pyplot
{
	public Pyplot()	{}
	public dynamic pyplot()
	{
		RunPythonScript RPS = new RunPythonScript();
		using (Py.GIL())
		{
			dynamic plot = Py.Import("matplotlib.pyplot");
			return plot;
		}
	}
}
