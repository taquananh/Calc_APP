﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            RemoveItem = new Button();
            ToggleVisibility = new Button();
            label1 = new Label();
            ModifyShapeComboBox = new ComboBox();
            menuStrip1 = new MenuStrip();
            chỉnhSửaToolStripMenuItem = new ToolStripMenuItem();
            AddPointToolStripMenuItem = new ToolStripMenuItem();
            thêmHìnhToolStripMenuItem = new ToolStripMenuItem();
            đToolStripMenuItem = new ToolStripMenuItem();
            AddPolynomialToolStripMenuItem = new ToolStripMenuItem();
            đườngTrònElipToolStripMenuItem = new ToolStripMenuItem();
            đaGiácToolStripMenuItem = new ToolStripMenuItem();
            groupBox3 = new GroupBox();
            button8 = new Button();
            ResultBox = new RichTextBox();
            label4 = new Label();
            CodeConfirm = new Button();
            CodeBox = new TextBox();
            label3 = new Label();
            groupBox4 = new GroupBox();
            yMax = new TextBox();
            label8 = new Label();
            xMax = new TextBox();
            label9 = new Label();
            yMin = new TextBox();
            label10 = new Label();
            xMin = new TextBox();
            label7 = new Label();
            label6 = new Label();
            ZoomConfirmation = new Button();
            label5 = new Label();
            groupBox1.SuspendLayout();
            menuStrip1.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(RemoveItem);
            groupBox1.Controls.Add(ToggleVisibility);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(ModifyShapeComboBox);
            groupBox1.ForeColor = Color.Black;
            groupBox1.Location = new Point(16, 31);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(312, 95);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Ẩn, hiện, xoá hình";
            // 
            // RemoveItem
            // 
            RemoveItem.Location = new Point(196, 58);
            RemoveItem.Name = "RemoveItem";
            RemoveItem.Size = new Size(94, 29);
            RemoveItem.TabIndex = 4;
            RemoveItem.Text = "Xoá hình";
            RemoveItem.UseVisualStyleBackColor = true;
            RemoveItem.Click += RemoveItem_Click;
            // 
            // ToggleVisibility
            // 
            ToggleVisibility.ForeColor = Color.Black;
            ToggleVisibility.Location = new Point(101, 58);
            ToggleVisibility.Name = "ToggleVisibility";
            ToggleVisibility.Size = new Size(94, 29);
            ToggleVisibility.TabIndex = 2;
            ToggleVisibility.Text = "Ẩn/Hiện hình";
            ToggleVisibility.UseVisualStyleBackColor = true;
            ToggleVisibility.Click += ToggleVisibility_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.Black;
            label1.Location = new Point(6, 28);
            label1.Name = "label1";
            label1.Size = new Size(78, 20);
            label1.TabIndex = 1;
            label1.Text = "Chọn hình:";
            label1.Click += label1_Click;
            // 
            // ModifyShapeComboBox
            // 
            ModifyShapeComboBox.FormattingEnabled = true;
            ModifyShapeComboBox.Location = new Point(90, 26);
            ModifyShapeComboBox.Name = "ModifyShapeComboBox";
            ModifyShapeComboBox.Size = new Size(210, 28);
            ModifyShapeComboBox.TabIndex = 0;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { chỉnhSửaToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(665, 28);
            menuStrip1.TabIndex = 4;
            menuStrip1.Text = "menuStrip1";
            // 
            // chỉnhSửaToolStripMenuItem
            // 
            chỉnhSửaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { AddPointToolStripMenuItem, thêmHìnhToolStripMenuItem });
            chỉnhSửaToolStripMenuItem.Name = "chỉnhSửaToolStripMenuItem";
            chỉnhSửaToolStripMenuItem.Size = new Size(92, 24);
            chỉnhSửaToolStripMenuItem.Text = "&Thêm hình";
            // 
            // AddPointToolStripMenuItem
            // 
            AddPointToolStripMenuItem.Name = "AddPointToolStripMenuItem";
            AddPointToolStripMenuItem.Size = new Size(224, 26);
            AddPointToolStripMenuItem.Text = "Thêm điểm";
            AddPointToolStripMenuItem.Click += AddPointToolStripMenuItem_Click;
            // 
            // thêmHìnhToolStripMenuItem
            // 
            thêmHìnhToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { đToolStripMenuItem, AddPolynomialToolStripMenuItem, đườngTrònElipToolStripMenuItem, đaGiácToolStripMenuItem });
            thêmHìnhToolStripMenuItem.Name = "thêmHìnhToolStripMenuItem";
            thêmHìnhToolStripMenuItem.Size = new Size(224, 26);
            thêmHìnhToolStripMenuItem.Text = "Thêm hình học khác";
            // 
            // đToolStripMenuItem
            // 
            đToolStripMenuItem.Name = "đToolStripMenuItem";
            đToolStripMenuItem.Size = new Size(327, 26);
            đToolStripMenuItem.Text = "Đoạn thẳng";
            đToolStripMenuItem.Click += đToolStripMenuItem_Click;
            // 
            // AddPolynomialToolStripMenuItem
            // 
            AddPolynomialToolStripMenuItem.Name = "AddPolynomialToolStripMenuItem";
            AddPolynomialToolStripMenuItem.Size = new Size(327, 26);
            AddPolynomialToolStripMenuItem.Text = "Đường thẳng/Quỹ tích hàm đa thức";
            AddPolynomialToolStripMenuItem.Click += AddPolynomialToolStripMenuItem_Click;
            // 
            // đườngTrònElipToolStripMenuItem
            // 
            đườngTrònElipToolStripMenuItem.Name = "đườngTrònElipToolStripMenuItem";
            đườngTrònElipToolStripMenuItem.Size = new Size(327, 26);
            đườngTrònElipToolStripMenuItem.Text = "Đường tròn";
            đườngTrònElipToolStripMenuItem.Click += đườngTrònElipToolStripMenuItem_Click;
            // 
            // đaGiácToolStripMenuItem
            // 
            đaGiácToolStripMenuItem.Name = "đaGiácToolStripMenuItem";
            đaGiácToolStripMenuItem.Size = new Size(327, 26);
            đaGiácToolStripMenuItem.Text = "Đa giác";
            đaGiácToolStripMenuItem.Click += đaGiácToolStripMenuItem_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(button8);
            groupBox3.Controls.Add(ResultBox);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(CodeConfirm);
            groupBox3.Controls.Add(CodeBox);
            groupBox3.Controls.Add(label3);
            groupBox3.ForeColor = Color.IndianRed;
            groupBox3.Location = new Point(342, 31);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(312, 277);
            groupBox3.TabIndex = 6;
            groupBox3.TabStop = false;
            groupBox3.Text = "Tính toán";
            // 
            // button8
            // 
            button8.Location = new Point(208, 19);
            button8.Name = "button8";
            button8.Size = new Size(94, 29);
            button8.TabIndex = 5;
            button8.Text = "Trợ giúp";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // ResultBox
            // 
            ResultBox.BackColor = SystemColors.Window;
            ResultBox.Location = new Point(8, 108);
            ResultBox.Name = "ResultBox";
            ResultBox.ReadOnly = true;
            ResultBox.Size = new Size(294, 157);
            ResultBox.TabIndex = 4;
            ResultBox.Text = "";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(8, 85);
            label4.Name = "label4";
            label4.Size = new Size(63, 20);
            label4.TabIndex = 3;
            label4.Text = "Kết quả:";
            // 
            // CodeConfirm
            // 
            CodeConfirm.Location = new Point(208, 54);
            CodeConfirm.Name = "CodeConfirm";
            CodeConfirm.Size = new Size(94, 29);
            CodeConfirm.TabIndex = 2;
            CodeConfirm.Text = "OK";
            CodeConfirm.UseVisualStyleBackColor = true;
            CodeConfirm.Click += CodeConfirm_Click;
            // 
            // CodeBox
            // 
            CodeBox.Location = new Point(8, 55);
            CodeBox.Name = "CodeBox";
            CodeBox.Size = new Size(194, 27);
            CodeBox.TabIndex = 1;
            CodeBox.TextChanged += textBox1_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 23);
            label3.Name = "label3";
            label3.Size = new Size(175, 20);
            label3.TabIndex = 0;
            label3.Text = "Gõ lệnh của bạn vào đây:";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(yMax);
            groupBox4.Controls.Add(label8);
            groupBox4.Controls.Add(xMax);
            groupBox4.Controls.Add(label9);
            groupBox4.Controls.Add(yMin);
            groupBox4.Controls.Add(label10);
            groupBox4.Controls.Add(xMin);
            groupBox4.Controls.Add(label7);
            groupBox4.Controls.Add(label6);
            groupBox4.Controls.Add(ZoomConfirmation);
            groupBox4.Controls.Add(label5);
            groupBox4.Location = new Point(16, 132);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(312, 176);
            groupBox4.TabIndex = 6;
            groupBox4.TabStop = false;
            groupBox4.Text = "Phóng to/Thu nhỏ đồ thị";
            // 
            // yMax
            // 
            yMax.Location = new Point(199, 101);
            yMax.Name = "yMax";
            yMax.Size = new Size(100, 27);
            yMax.TabIndex = 17;
            yMax.TextChanged += textBox2_TextChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(156, 104);
            label8.Name = "label8";
            label8.Size = new Size(37, 20);
            label8.TabIndex = 16;
            label8.Text = "Max";
            // 
            // xMax
            // 
            xMax.Location = new Point(199, 46);
            xMax.Name = "xMax";
            xMax.Size = new Size(100, 27);
            xMax.TabIndex = 15;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(156, 49);
            label9.Name = "label9";
            label9.Size = new Size(37, 20);
            label9.TabIndex = 14;
            label9.Text = "Max";
            // 
            // yMin
            // 
            yMin.Location = new Point(45, 101);
            yMin.Name = "yMin";
            yMin.Size = new Size(100, 27);
            yMin.TabIndex = 13;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(6, 104);
            label10.Name = "label10";
            label10.Size = new Size(34, 20);
            label10.TabIndex = 11;
            label10.Text = "Min";
            // 
            // xMin
            // 
            xMin.Location = new Point(45, 46);
            xMin.Name = "xMin";
            xMin.Size = new Size(100, 27);
            xMin.TabIndex = 9;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 49);
            label7.Name = "label7";
            label7.Size = new Size(34, 20);
            label7.TabIndex = 7;
            label7.Text = "Min";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 76);
            label6.Name = "label6";
            label6.Size = new Size(159, 20);
            label6.TabIndex = 5;
            label6.Text = "Nhập giới hạn tung độ";
            // 
            // ZoomConfirmation
            // 
            ZoomConfirmation.Location = new Point(206, 135);
            ZoomConfirmation.Name = "ZoomConfirmation";
            ZoomConfirmation.Size = new Size(94, 29);
            ZoomConfirmation.TabIndex = 3;
            ZoomConfirmation.Text = "OK";
            ZoomConfirmation.UseVisualStyleBackColor = true;
            ZoomConfirmation.Click += ZoomConfirmation_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 23);
            label5.Name = "label5";
            label5.Size = new Size(170, 20);
            label5.TabIndex = 1;
            label5.Text = "Nhập giới hạn hoành độ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(665, 322);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Bảng điều khiển";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private ComboBox ModifyShapeComboBox;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem chỉnhSửaToolStripMenuItem;
        private ToolStripMenuItem AddPointToolStripMenuItem;
        private ToolStripMenuItem thêmHìnhToolStripMenuItem;
        private ToolStripMenuItem đToolStripMenuItem;
        private ToolStripMenuItem AddPolynomialToolStripMenuItem;
        private ToolStripMenuItem đườngTrònElipToolStripMenuItem;
        private ToolStripMenuItem đaGiácToolStripMenuItem;
        private Button RemoveItem;
        private Button ToggleVisibility;
        private GroupBox groupBox3;
        private TextBox CodeBox;
        private Label label3;
        private RichTextBox ResultBox;
        private Label label4;
        private Button CodeConfirm;
        private GroupBox groupBox4;
        private Label label6;
        private Button ZoomConfirmation;
        private Label label5;
        private TextBox yMin;
        private Label label10;
        private TextBox xMin;
        private Label label7;
        private TextBox yMax;
        private Label label8;
        private TextBox xMax;
        private Label label9;
        private Button button8;
    }
}
