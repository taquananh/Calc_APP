﻿using Python.Runtime;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1;

namespace CalcApp
{
    public partial class AddPointDialog : Form
    {
        public AddPointDialog()
        {
            InitializeComponent();
        }

        public RunPythonScript RPS = new RunPythonScript();
        public dynamic OCP, Plotting, Space;
        public dynamic Plot = (new Pyplot()).pyplot();

        private void AddPointDialog_Load(object sender, EventArgs e)
        {
            //RPS.RunScript();
            OCP = RPS.OpenClosePlot();
            Plotting = RPS.Plotting();
        }

        private void Confirm_Click(object sender, EventArgs e)
        {
            float float1, float2;
            bool check1, check2;
            check1 = float.TryParse(xValueBox.Text, out float1);
            check2 = float.TryParse(yValueBox.Text, out float2);

            if (check1 && check2)
                using (Py.GIL())
                {
                    PyFloat x = new PyFloat(float1);
                    PyFloat y = new PyFloat(float2);
                    PyString name = new PyString(NameBox.Text);

                    dynamic obj = Plotting.Shapes.Point(x, y, name);
                    //Plot.plot(x, y, "o");
                    Form1.Surface.InvokeMethod("Plot", new PyObject[] { obj });
                    Form1.Surface.InvokeMethod("AddItem", new PyObject[] { obj });
                    OCP.ShowPlot();

                    string objname = obj.name;
                    Form1.NewItems(objname);
                    //PyObject A = Surface.Point().InvokeMethod("Point", new PyObject[] { x, y });
                }
        }
    }
}
